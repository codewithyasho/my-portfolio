<!DOCTYPE html>
<html>
<head>
  <title>POST Method Single File</title>
</head>
<body>

<h2>Enter Your Details</h2>

<form method="post">
  Name: <input type="text" name="name"><br><br>
  Email: <input type="text" name="email"><br><br>
  <input type="submit" value="Submit">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = $_POST['name'];
  $email = $_POST['email'];

  echo "<h3>Submitted Details</h3>";
  echo "Name: " . $name . "<br>";
  echo "Email: " . $email;
}
?>

</body>
</html>