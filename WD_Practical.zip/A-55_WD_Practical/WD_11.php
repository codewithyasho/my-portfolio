<!DOCTYPE html>
<html>
<body>

<form method="post">
  Enter String: <input type="text" name="str">
  <input type="submit" value="Submit">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $str = $_POST['str'];

  echo "<h3>Results:</h3>";
  echo "Original String: " . $str . "<br>";

  // Length
  echo "Length: " . strlen($str) . "<br>";

  // Reverse
  echo "Reverse: " . strrev($str) . "<br>";

  // Substring (first 3 characters)
  echo "Substring (first 3 chars): " . substr($str, 0, 3);
}
?>

</body>
</html>