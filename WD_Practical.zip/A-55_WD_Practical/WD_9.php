<!DOCTYPE html>
<html>
<body>

<h2>Welcome</h2>

<?php
date_default_timezone_set("Asia/Kolkata");
echo date("d-m-Y H:i:s");
?>

</body>
</html>