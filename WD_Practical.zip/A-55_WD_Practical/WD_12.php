<?php
// Create an array
$fruits = array("Apple", "Banana", "Mango", "Orange");

// Display array values
echo "<h3>Fruits List:</h3>";

foreach ($fruits as $value) {
  echo $value . "<br>";
}
?>